// TEST RFID 

// INCLUDE

#include <avr/io.h>
#include <avr/interrupt.h>

#include "Main.h"
#include "TIMERS.h"
#include "USART.h"



// Mes variables globales



// Prototype des fonctions

//********************************************************




//****************** fonction principale *****************
int main (void)
{

 	/* initialize TIMER */


	/* initialise USART */


	/* initialise Port Sortie */


	/* initialise Port Entr�e */



	/* initialise Interruptions */


 	/* Lancement Boucle infinie) */


 while(1)
 	 {
  		 
    
  	 }



}

//****************************************
//  CONTENU DES FONCTIONS
//****************************************





//****************************************
//  ROUTINE INTERRUPTIONS
//****************************************

//Interruption TIMER1
ISR(TIMER1_OVF_vect)
{

}	


//Interruption INT0
ISR(INT0_vect)
{

}


