// USART.h

#ifndef _USART_H_
#define _USART_H_


//DEFINE


//PROTOTYPE FONCTIONS EXTERNES
void Usart_Tx(char data);
void USART_Init_9600(void);



#endif /* _USART_H */
