// Hardware.h

#ifndef _HARDWARE_H_
#define _HARDWARE_H_


//DEFINE


//PROTOTYPE FONCTIONS EXTERNES
void Init_Hardware(unsigned char Number_Manip);




#endif /* _HARDWARE_H */
