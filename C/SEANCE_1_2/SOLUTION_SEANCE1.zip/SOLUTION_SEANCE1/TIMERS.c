//FONCTIONS TIMER


//INCLUDE
#include "TIMERS.h"
#include "Main.h"
#include <avr/io.h>



//DECLARATION DES VARIABLES GLOGALES


//PROTOTYPE FONCTIONS INTERNES



//CONTENU FONCTIONS EXTERNES


void TIMER1_Init_1ms(void)
{
	//En mode compteur le registre TCCR1A = 0x00
	//Si diviseur par 1 -> 1000000/1 = 1000 Khz
	// Une p�riode = 1�S
	// Si je compte jusque 1000 --> 1000 X 1 = 1 ms
	
	TCCR1A = 0x00;
	TCCR1B |= (0<<CS12)|(0<<CS11)|(1<<CS10);
	// Valeur initiale du compteur = 65536 - 1000 = 64536
	TCNT1H = 0xFC;
	TCNT1L = 0x17;
	// Autorisation de l'interruption en cas d'overflow
	TIMSK1 |= (1<<TOIE1);

}



//CONTENU FONCTIONS INTERNES
