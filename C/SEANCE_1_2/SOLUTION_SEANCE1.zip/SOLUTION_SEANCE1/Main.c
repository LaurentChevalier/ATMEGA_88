// TEST RFID 

// INCLUDE

#include <avr/io.h>
#include <avr/interrupt.h>

#include "Main.h"
#include "TIMERS.h"
#include "USART.h"



char Relais_Active[] = "RELAIS ACTIVE ";
char Relais_Desactive[] = "RELAIS DESACTIVE ";

// Mes variables globales
volatile unsigned int Cpt_Timer1;
volatile unsigned char Relais;


// Prototype des fonctions

//********************************************************




//****************** fonction principale *****************
int main (void)
{
	
 	/* initialize TIMER */
	TIMER1_Init_1ms();


	/* initialise USART */
	USART_Init_9600();


	/* Configuration I/O */
	//LED en PD7 en mode Output
  	sbiBF(DDRD,DDD7);

	// LED OFF au d�marrage
	cbiBF(PORTD,PD7)
	;
	// RELAIS en PD6 en mode Output
	sbiBF(DDRD,DDD6);

	// Contacts RELAIS ouverts au d�marrage
	Relais = FALSE;
	cbiBF(PORTD,PD6)
	;
	// Bouton poussoir en PD2 en mode Input 
	cbiBF(DDRD,DDD2);
	// Pull UP en PD2 enabled
	cbiBF(PORTD,PD2);

	// Interruption externe via INT0 de la broche PD2 enabled (voir DS page 68)
	sbiBF(EIMSK,INT0);

	// Interruption sur Niveau Bas
	EICRA|=(0<<ISC01)|(0<<ISC00);

	

	/* initialise Interruptions */
	sei();
	



 	/* Lancement Boucle infinie) */

 while(1)
 	 {
  		 if (Cpt_Timer1==1000) 
		 {
			Cpt_Timer1=0;
			
			sbiBF(PIND, PIND7);	// Toggle
					
	     }
    
  	 }

}



//****************************************
//  CONTENU DES FONCTIONS
//****************************************





//****************************************
//  ROUTINE INTERRUPTIONS
//****************************************

//Interruption TIMER1
ISR(TIMER1_OVF_vect)
{
	Cpt_Timer1++;
	TCNT1H = 0xFC;
	TCNT1L = 0x17;


}	


//Interruption INT0
ISR(INT0_vect)
{	
	Relais = !Relais;
	sbiBF(PIND, PIND6);	// Toggle Relais
	if (Relais == TRUE) Usart_Tx_String(Relais_Active);
	else Usart_Tx_String(Relais_Desactive);		
}


